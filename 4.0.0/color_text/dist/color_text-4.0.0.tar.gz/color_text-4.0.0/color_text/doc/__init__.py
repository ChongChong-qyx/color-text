"""
Help ducuments.
帮助文档。
"""

def doc():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.doc')
	del os
	del sys

def docx():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.docx')
	del os
	del sys

def markdown():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.md')
	del os
	del sys

def html():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.mhtml')
	del os
	del sys

def odt():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.odt')
	del os
	del sys

def pdf():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.pdf')
	del os
	del sys

def rtf():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.rtf')
	del os
	del sys

def xml():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.xml')
	del os
	del sys

def xps():
	import sys
	import os
	os.startfile(sys.path[5] + '\\color_text\\doc\\' + 'help.xps')
	del os
	del sys
