import color_text.examples
