#-*- coding:utf-8 -*-#

from color_text import *

Print("这是一段文字")

printLightRed("这是一段浅红色的文字。")
printYellow("这是一段黄色的文字。")
printRed("这是一段红色的文字。")
printGreen("这是一段绿色的文字。")
printBlack("这是一段黑色的文字。")
printBlue("这是一段蓝色的文字。")
printPurple("这是一段紫色的文字。")
printWhite("这是一段白色的文字。")
printGrey("这是一段灰色的文字。")
printGray("这也是一段灰色的文字。")
printLightBlue("这是一段浅蓝色的文字。")
printVeryLightGreen("这是一段很浅的绿色的文字。")
printLightPurple("这是一段浅紫色的文字。")
printLightYellow("这是一段浅黄色的文字。")
printGlossWhite("这是一段亮白色的文字。")
printLightGreen("这是一段浅绿色的文字。")
printLightGreen("这也是一段浅绿色的文字。", 2)
example()

