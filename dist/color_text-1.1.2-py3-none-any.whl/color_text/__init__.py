from .print_color_text import printLightRed, printYellow, printRed, printGreen, printBlack, printBlue, printPurple, printWhite
from .print_color_text import printGrey, printGray, printLightBlue, printVeryLightGreen, printLightPurple, printLightYellow
from .print_color_text import printGlossWhite, printLightGreen, example, Print

__version__ = '1.1.2'
