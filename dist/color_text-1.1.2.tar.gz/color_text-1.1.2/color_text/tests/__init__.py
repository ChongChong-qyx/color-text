#这是一个无用的文件
#This file is useless
#C’est un document inutile
#이것은 무용한 공문서이다
#これは無用な文書である
#Das ist kein dokument
#Это бесполезный документ
#É um arquivo inútil
#Es UN documento inútil
#這是一個無用的文件
#Ovo je beskorisna datoteka
#Si tratta di un documento inutile
