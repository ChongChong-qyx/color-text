#-*- coding:utf-8 -*-#

import color_text

try:
	del sys
except:
	del ctypes
else:
	del ctypes
