"""
Help ducuments.
帮助文档。
"""

def doc():
	import os
	os.startfile('doc/help.doc')
	del os

def docx():
	import os
	os.startfile('doc/help.docx')
	del os

def markdown():
	import os
	os.startfile('doc/help.md')
	del os

def html():
	import os
	os.startfile('doc/help.mhtml')
	del os

def odt():
	import os
	os.startfile('doc/help.odt')
	del os

def pdf():
	import os
	os.startfile('doc/help.pdf')
	del os

def rtf():
	import os
	os.startfile('doc/help.rtf')
	del os

def xml():
	import os
	os.startfile('doc/help.xml')
	del os

def xps():
	import os
	os.startfile('doc/help.xps')
	del os
