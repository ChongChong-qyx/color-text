"""
A example for output.
一个输出的例子。
"""

from color_text import output_example

output_example()
