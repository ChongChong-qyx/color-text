from color_text import output_example

output_example()
